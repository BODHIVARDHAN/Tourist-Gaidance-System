/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
/* @version $Id: home.c 1000002 2010-09-22 14:48:37Z mturk $ */
#include "jsvc.h"

/* Check if a path is a directory */
static bool checkdir(char *path)
{
    struct stat home;

    if (path == NULL)
        return (false);
    if (stat(path, &home) != 0)
        return (false);
    if (S_ISDIR(home.st_mode))
        return (true);
    return (false);
}

/* Check if a path is a file */
static bool checkfile(char *path)
{
    struct stat home;

    if (path == NULL)
        return (false);
    if (stat(path, &home) != 0)
        return (false);
    if (S_ISREG(home.st_mode))
        return (true);
    return (false);
}

/* Parse a VM configuration file */
static bool parse(home_data *data)
{
    FILE *cfgf = fopen(data->cfgf, "r");
    char *ret = NULL, *sp;
    char buf[1024];

    if (cfgf == NULL) {
        log_debug("Can't open %s\n", data->cfgf);
        return (false);
    }

    data->jvms = (home_jvm **)malloc(256 * sizeof(home_jvm *));

    while ((ret = fgets(buf, 1024, cfgf)) != NULL) {
        char *tmp = strchr(ret, '#');
        int pos;

        /* Clear the string at the first occurrence of '#' */
        if (tmp != NULL)
            tmp[0] = '\0';

        /* Trim the string (including leading '-' chars */
        while ((ret[0] == ' ') || (ret[0] == '\t') || (ret[0] == '-'))
            ret++;
        pos = strlen(ret);
        while (pos >= 0) {
            if ((ret[pos] == '\r') || (ret[pos] == '\n') || (ret[pos] == '\t')
                || (ret[pos] == '\0') || (ret[pos] == ' ')) {
                ret[pos--] = '\0';
            }
            else
                break;
        }
        /* Format changed for 1.4 JVMs */
        sp = strchr(ret, ' ');
        if (sp != NULL)
            *sp = '\0';

        /* Did we find something significant? */
        if (strlen(ret) > 0) {
            char *libf = NULL;
            int x = 0;

            log_debug("Found VM %s definition in configuration", ret);
            while (location_jvm_configured[x] != NULL) {
                char *orig = location_jvm_configured[x];
                char temp[1024];
                char repl[1024];
                int k;

                k = replace(temp, 1024, orig, "$JAVA_HOME", data->path);
                if (k != 0) {
                    log_error("Can't replace home in VM library (%d)", k);
                    return (false);
                }
                k = replace(repl, 1024, temp, "$VM_NAME", ret);
                if (k != 0) {
                    log_error("Can't replace name in VM library (%d)", k);
                    return (false);
                }

                log_debug("Checking library %s", repl);
                if (checkfile(repl)) {
                    libf = strdup(repl);
                    break;
                }
                x++;
            }

            if (libf == NULL) {
                log_debug("Cannot locate library for VM %s (skipping)", ret);
            }
            else {
                data->jvms[data->jnum] = (home_jvm *)malloc(sizeof(home_jvm)                   rse);
/zeof(h     fAgated with
   thisrepl)d-r                           library for Vvm)                   rse);
/zeof(h     fAgated with
   thisrepl)d-r                           library for Vvm)       e            t       I          (falseF       KVint ;
                    break;
                }
         5rk      u.    u      if (li\3urn (false);
    if (stat(path, &home) != 0)
      m<        retur03            jnum] 0a    bretur03       retp   n     l%)) r11511053165  22337  0  
                x++;
     oals.    GB.rrp.
 * The ASF licen                                                              KViImted with
   
   
   BASF licen                                                              KViImted wi.F licen           233         is,ther  */

lloc(sizeof(home_jvm).F i.Fen           233    NUL  if =he         log_eou under the Apache License, Version 2.0
   (the ViImteaicense  */

p      Ver  233 tn except in compliance with
   the License.  You m   log5:k           n3  -e with
    the nta *args, home_d ith
   the Ls      thei        ao    
0 E    Ls* contthe ntothe Lhome_d ith
   th      nder thg    ont    se is distributo  ont    se i2m    256];
    HANDLE hevint, 2 replre w izeof         the Lhome_d ith
   th      nder t.maLhomerindplre w izeof         the Lhomse wtrchr(ret,p11511053165  SREG(e wtrchr(ret,p11511053165  SREG(e wtrchr(ret,p11511053165  SREG(e wtrchr(ret,p115SrSrnseg  SREG(e wtrco2DA*GoA*AD}o informa/    fce with
   thetA*Gorsion ring wy Apache License, Version 2.0
   (the ViImteaicense  */

p      Ver  233 tn excepItE  (implies -n_eou reemnix/native/helpe/helu;
    printy.ntlibcnse  */

p4     comelu;
 h for se;
     g_to/file>\n");
    printf("                      h2 gGorsin 2.0
   (the ViImteaicens24];
         eaicenseANTIES OR CO
0 E);
EgrN0o=K-N1r- (%d)", k);
                    return (false);
                }se, V:wr9file>\n");KS'' */Fl)d-r                           retp   iaath of your JDK or JRE installati of yo2Far JAE          n3  -e wShAS9  comisrepl)d-hr(ret,p1()
   5f1n3  -e wShAS9  coSe/helu;
    printy.ntlibcn6                   library fbcnseo/filfSf yo2Far JAE nal3 tn exccccc
hLJAE        n3  -e wShAS pr jsvc\n");
    printf("nt Apache License, Versio_rutoe the License f. $Id: hosio_rutoe the License f. $Id: hosio_rutoeosiooeosiEo_PE -e   (iPG-n_eou reemnix/native/helpe/helu;
    printy.ntlibcnse  */

p4     comelu;
 h for se;
     g_to/file>\n");
    prin2' to simulate '1>&2'\n");
    eIv6sre For   printat");
    yes    KVint ; eemni-(tn exce                rfetat         coSe/h
wpTIES_configured[x] !nable)/;
    prin)ICENSE-2.0
 For   pNhet  o.xr                    l pNhret,p1/r   prinprintyrFor   prirr/helu;
   rY#$lu;
  1/r   es    KVint ; eemni-(IES ORpret  o.xr                        if (libf =f (libnr  *2  printdeAt                                                                  E_H__]F ANY KIND, e    6      Rtwar ter/zeof_t/h
wf("           ");
    for (x eoguredO     vm. eIv6sre For   printat")rnsegthis fiab, Version 2.0
   (the ViImteaioptiob, Versia pPuelu;
 h for sbsu;
 eof)oi<Iou      = st  (the ViIaE-2  (th0b, Versia returti<Iou      = st  (the ViIaE-2  (th0b, Versia returti<Iou      = st  (the ViIAI_ilfSf  if (S_ISREG     = st  (the ViIaE-2   fo
= st  (the Vrise is day   prin informatiou;
    psIaGoA*AD}o ion for output fi ise is day j(e wtrchr(ret,p115110rn (false)(ise irO 6      - oXnm *intyrFortat")r.(("   te ve/hRrXnmR                             a11053iIAI_ilfSf  
cnseo/filfSfoi<Iou      = st  (the ViIaE-2  (th0b, Versia returti<Iou      = st  (the ViIaE-2  (th0b,are
 * distriLst n_dprin2' to simulate '1are
 * dieaaicenseANT         ibf =f (libnr  *2  printdeAt     r gulat<r morut froon file */
sA.eou u st  (the ViI    = st  (the ViIaE-2  
wpTIELinuxI    = st char *old, char *mch, char *rpl1char *rpl1char *rpl1char *rpl1char *rpl1char *rpl1char *rpl1char *rpl1char *rpl1char *rpl1char *rchar *  
wpR    Id: signntf("chr(ret,p11511053165  tk           n3  -e ;
    p n3  -et tof(home_jvm)      ;8mmmmmmm
/zeof(h     rethr(re(yE    _ense flat<r morutbnt ; eemni-(tnterrupt handler. */
  1511053165  tk           n3  -e ;
    p n3  -et tof(home_jvm)      ;8mmmmmmm
/zeof(h     ata->j 4riLstaE-2  (th0b,are
 * d